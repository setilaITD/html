
function Hello() {

	var user = prompt("What is your name");
document.getElementById('here').innerHTML = " Hello " + user +" Welcom to my website";

}
 //and then

function Hello2() {

	var user = prompt("What is your name");
document.getElementById('here2').innerHTML = " Hello " + user +" Welcom to my website";

}

